package Project;

import View07175.Revie07175_GUI;

public class Revie07175_Main {
    public static void main(String[] args) {
        Revie07175_GUI main = new Revie07175_GUI();
    }
}
