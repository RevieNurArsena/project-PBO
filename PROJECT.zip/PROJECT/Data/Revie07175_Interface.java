package Data;

public interface Revie07175_Interface {
    public void view();
}
