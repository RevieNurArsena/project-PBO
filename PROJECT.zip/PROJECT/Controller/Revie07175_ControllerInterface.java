package Controller;

public interface Revie07175_ControllerInterface {
    public boolean login(String id, String pass);
}
