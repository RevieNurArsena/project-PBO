package Controller;

import Data.Revie07175_DataPenjual;
import Data.Revie07175_DataObjMeja;
import Data.Revie07175_DataObjLemari;

public class Revie07175_AllObjectModel {
    public static Revie07175_DataPenjual penjual = new Revie07175_DataPenjual();
    public static Revie07175_DataObjMeja ObjMeja = new Revie07175_DataObjMeja();
    public static Revie07175_DataObjLemari ObjLemari = new Revie07175_DataObjLemari();
}
